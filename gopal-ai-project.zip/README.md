# GOPAL AI V1 — Android

Project Android dengan GitHub Actions untuk build APK langsung dari GitHub.

## Build APK dari HP

1. Buat repository baru di GitHub.
2. Upload seluruh isi project ini.
3. Buka tab **Actions**.
4. Pilih **Build GOPAL AI APK**.
5. Tekan **Run workflow**.
6. Tunggu sampai proses selesai.
7. Buka hasil workflow dan cari **Artifacts**.
8. Download `GOPAL-AI-V1-debug`.
9. Ekstrak ZIP tersebut dan install `app-debug.apk`.

Workflow juga otomatis berjalan ketika ada push ke branch `main`.

## Isi V1

- Jetpack Compose UI
- Chat interface
- SpeechRecognizer
- Android Text-to-Speech
- LlamaEngine sebagai titik integrasi llama.cpp
- Folder model/voice

Model GGUF dan binary native llama.cpp belum dibundel.
