package com.gopal.ai.ai

class ChatManager(private val engine: LlamaEngine) {
    suspend fun reply(message: String): String {
        val system = """
            You are GOPAL AI, a helpful general-purpose assistant.
            Answer clearly and naturally.
            User message:
            $message
        """.trimIndent()
        return engine.generate(system)
    }
}
