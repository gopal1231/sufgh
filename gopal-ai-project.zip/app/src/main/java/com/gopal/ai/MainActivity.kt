package com.gopal.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.gopal.ai.ai.ChatManager
import com.gopal.ai.ai.LlamaEngine
import com.gopal.ai.model.ChatMessage
import com.gopal.ai.voice.SpeechRecognizerManager
import com.gopal.ai.voice.TTSManager
import kotlinx.coroutines.launch

private val Bg = Color(0xFF09070D)
private val Panel = Color(0xFF14101C)
private val Purple = Color(0xFF8B5CF6)
private val TextMain = Color(0xFFF5F3FF)
private val Muted = Color(0xFFA9A2B7)

class MainActivity : ComponentActivity() {
    private lateinit var tts: TTSManager
    private lateinit var speech: SpeechRecognizerManager

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TTSManager(this)

        setContent {
            val scope = rememberCoroutineScope()
            val engine = remember { LlamaEngine() }
            val chat = remember { ChatManager(engine) }

            var input by remember { mutableStateOf("") }
            var listening by remember { mutableStateOf(false) }
            val messages = remember {
                mutableStateListOf(
                    ChatMessage(
                        "Halo, aku GOPAL AI V1. Voice input dan output sudah disiapkan.",
                        false
                    )
                )
            }

            speech = remember {
                SpeechRecognizerManager(
                    this,
                    onResult = { input = it },
                    onState = { listening = it }
                )
            }

            GopalTheme {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Bg)
                        .padding(14.dp)
                ) {
                    Header()

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(vertical = 12.dp)
                    ) {
                        items(messages) { msg ->
                            MessageBubble(msg)
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Tulis sesuatu...", color = Muted) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Purple,
                                unfocusedBorderColor = Color(0xFF393244),
                                focusedTextColor = TextMain,
                                unfocusedTextColor = TextMain,
                                cursorColor = Purple
                            ),
                            shape = RoundedCornerShape(18.dp)
                        )

                        Button(
                            onClick = {
                                if (ContextCompat.checkSelfPermission(
                                        this,
                                        Manifest.permission.RECORD_AUDIO
                                    ) != PackageManager.PERMISSION_GRANTED
                                ) {
                                    micPermission.launch(Manifest.permission.RECORD_AUDIO)
                                } else {
                                    speech.start()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (listening) Color(0xFFB4234D) else Panel
                            ),
                            contentPadding = PaddingValues(14.dp)
                        ) {
                            Text("🎙")
                        }

                        Button(
                            onClick = {
                                val prompt = input.trim()
                                if (prompt.isEmpty()) return@Button

                                input = ""
                                messages += ChatMessage(prompt, true)

                                scope.launch {
                                    val answer = chat.reply(prompt)
                                    messages += ChatMessage(answer, false)
                                    tts.speak(answer)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Purple),
                            contentPadding = PaddingValues(14.dp)
                        ) {
                            Text("➤", fontSize = 20.sp)
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        if (::speech.isInitialized) speech.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun Header() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            "GOPAL AI",
            color = TextMain,
            fontSize = 27.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            "LOCAL VOICE ASSISTANT • V1",
            color = Purple,
            fontSize = 11.sp,
            letterSpacing = 1.5.sp
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (message.fromUser) Purple else Panel,
            shape = RoundedCornerShape(16.dp)
        ) {
            Text(
                message.text,
                color = TextMain,
                modifier = Modifier.padding(13.dp),
                fontSize = 15.sp
            )
        }
    }
}

@Composable
private fun GopalTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Purple,
            onPrimary = Color.White
        ),
        content = content
    )
}
