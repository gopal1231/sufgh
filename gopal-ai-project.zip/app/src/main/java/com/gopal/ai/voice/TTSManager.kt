package com.gopal.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class TTSManager(context: Context) {
    private var ready = false
    private val tts = TextToSpeech(context) {
        ready = it == TextToSpeech.SUCCESS
        if (ready) {
            tts.language = Locale("id", "ID")
            tts.setSpeechRate(0.92f)
            tts.setPitch(1.18f)
        }
    }

    fun speak(text: String) {
        if (!ready) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "gopal-ai")
    }

    fun stop() {
        tts.stop()
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}
