package com.gopal.ai.ai

import kotlinx.coroutines.delay

/**
 * Local AI bridge.
 *
 * This class is intentionally isolated so llama.cpp JNI can be attached
 * without changing the Compose UI.
 */
class LlamaEngine {

    private var modelLoaded = false
    private var modelName = "No GGUF model loaded"

    fun loadModel(name: String) {
        modelName = name
        // TODO: Connect this point to llama.cpp JNI.
        modelLoaded = true
    }

    suspend fun generate(prompt: String): String {
        delay(250)

        if (!modelLoaded) {
            return "Model lokal belum dipasang. Tambahkan file GGUF ke folder models lalu hubungkan llama.cpp JNI di LlamaEngine.kt."
        }

        return "GOPAL AI lokal siap. Model \"$modelName\" sudah dipilih. Native llama.cpp inference dapat dihubungkan pada engine ini."
    }

    fun isLoaded() = modelLoaded
    fun currentModel() = modelName
}
